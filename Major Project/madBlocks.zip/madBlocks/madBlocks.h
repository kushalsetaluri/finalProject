/*****************************
Library for OLP Dashboard by Madhu Parvathaneni
******************************/

#ifndef madBlocks_H_
#define madBlocks_H_
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#define madBlocks_RETRY_DELAY 1000  // 1000ms

class madBlocks {
public:
	int read(String,String);
                 void write(String,String);
};


#endif /* madBlocks_H_ */