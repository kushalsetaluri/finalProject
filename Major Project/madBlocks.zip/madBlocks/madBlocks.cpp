#include "madBlocks.h"
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include<ESP8266HTTPClient.h>

WiFiClient client;

String request_string;

HTTPClient http;

int madBlocks::read(String apiKey,String trigCommand)
{
	String l_line="";
  	const char* host="madblocks.tech";
  	WiFiClient client;
  	if (client.connect(host,80))
  	{
  		String url = "http://madblocks.tech/dashboard/device_pull.php?device_api_key=" + String(apiKey);
  		client.print(String("GET ") + url + " HTTP/1.1\r\n" +
               		"Host: " + host + "\r\n" +
               		"Content-Type: application/x-www-form-urlencoded\r\n" +
               		"Connection: close\r\n\r\n");
  		Serial.println("Reading Data From Cloud");
  		delay(1000);
  		while(!client.available())
  		{
     			delay(1);
  		}
  		l_line = client.readString();
  		if (l_line!= "")
  		{
      			int commaIndex=l_line.indexOf("Device Status");
      			int secondCommaIndex = l_line.indexOf(',', commaIndex+1);
      			int thirdCommaIndex=l_line.indexOf(',',secondCommaIndex+1);
      			int fourthCommaIndex=l_line.indexOf(':',thirdCommaIndex+1);
      			int fifthCommaIndex=l_line.indexOf('}',fourthCommaIndex+1);

      			String s1= l_line.substring(0, commaIndex);
      			String s2 =l_line.substring(commaIndex+1, secondCommaIndex);
      			String s3 = l_line.substring(secondCommaIndex+1,thirdCommaIndex);
      			String s4  = l_line.substring(thirdCommaIndex+1,fourthCommaIndex);
      			String s5 = l_line.substring(fourthCommaIndex+1,fifthCommaIndex);

      			if(s2!="")
      			{
        				int commaIndex1=s2.indexOf(':');
        				int secondCommaIndex1 = s2.indexOf('"', commaIndex1+1);
        				String s51= s2.substring(0, commaIndex1);
        				String s52 =s2.substring(commaIndex1+1, secondCommaIndex1);
        				String main_data="";
        				int count_data=0;
        				//Serial.print("Temp Data: ");
        				//Serial.println(s52);
        				for (int k=0;k<s52.length();k++)
        				{
          					if (s52[k]=='<')
          					{
            						count_data+=1;
          					}
          					if(count_data==0)
          					{
            						main_data+=s52[k];
          					}
        				}
        				Serial.print("Field Data :");
        				//Serial.println(s51);
        				main_data.trim();
        				Serial.println(main_data);
        				return (main_data.equals(trigCommand));
			}
    		}
    		Serial.println("Data Read Successfully");
	}
}

void madBlocks::write(String apiKey,String data)
{
      
    if (client.connect("madblocks.tech",80))  
  {
     Serial.println("Uploading Data");
      request_string = "http://madblocks.tech/dashboard/device_push.php?device_api_key=";
      request_string += apiKey;
      request_string += "&device_status=";
      request_string += data;
      http.begin(request_string);
      http.GET();
      http.end();
    }
    Serial.println("Data Uploaded");
}